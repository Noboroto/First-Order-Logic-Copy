% Define a rule
parent(john, mary).

% Query the rule
?- parent(john, mary).